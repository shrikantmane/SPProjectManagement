import * as React from 'react';
import {sp, ItemAddResult} from "@pnp/sp";

export interface IRetriveTeamMember {
 items:ISpTaskItem[];
}

export interface ISpTaskItem{
    Id?: number;
    ProjectID?: string;
    StartDate?: string;
    EndDate?: string;
    TeamMember: {
      ID: number,
      Title: string
    }
    Status?: string;
  }

export default class TeamMember extends React.Component<{},IRetriveTeamMember > {

      constructor(props: {}, state:IRetriveTeamMember) {
    super(props);
    this.state = {
      items: []
    };
  }

   public componentDidMount() {
       this._getListItems();
  }
   
    //   public render(): React.ReactElement<IRetriveTeamMember> {
    //     return (
    //      <div>
    //         {this.state.items.map(function(item,key){
    //              return (
    //            <div>
    //             <table>
    //                <tr>
    //                   <td>{item.TeamMember.Title} </td>
    //                </tr>
    //            </table>
    //            </div>
    //             );
    //         })}
    //         test 
    //        </div>

           
           
    //     );
    //   }

      public render(): React.ReactElement<IRetriveTeamMember> {
     return (  
        <div>
            <div className="container">
                <div className="row">
                    <div className="panel panel-default user_panel">
                        <div className="panel-heading">
                            <b><h3 className="panel-title">Productivity Leaderboard</h3></b>
                        </div>

                        {this.state.items.map(function(item,key){  
                         
                                return (
                                <div className="panel-body">
                                    <div className="table-container">
                                        <table className="table-users table" style={{ Border : "0"}} >
                                            <tbody>
                                                 <tr>
                                                      <td>{item.TeamMember.Title} </td>
                                                 </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                );
                        })}


                    </div>
                </div>
            </div>
        </div>
    );  
  } 

   private _getListItems(): void {
    //Get all list items
    // sp.web.lists.getById("Project Team Member")
    let list = sp.web.lists.getByTitle("Project Team Member");
       list.items
      .select("ID","ProjectID", "TeamMember/Title", "TeamMember/ID", "StartDate", "EndDate", "Status").expand("TeamMember")
      .get()
      .then((response) => {
        console.log(response);
        this.setState({
          items: response
        });
      });
  }

}












// import * as React from 'react';

// export interface IRetriveTeamMember {
 
// }

// export default class TeamMember extends React.Component<{},IRetriveTeamMember > {
   
//       public render(): React.ReactElement<IRetriveTeamMember> {
//         return (
//             <div></div>
//         );
//       }

// }