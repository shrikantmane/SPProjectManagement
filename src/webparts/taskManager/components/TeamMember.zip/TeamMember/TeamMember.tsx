import * as React from 'react';
import { PrimaryButton, DefaultButton } from 'office-ui-fabric-react/lib/Button';
import { Dialog, DialogType, DialogFooter } from 'office-ui-fabric-react/lib/Dialog';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import {sp, ItemAddResult} from "@pnp/sp";
import { TooltipHost, DirectionalHint  } from 'office-ui-fabric-react/lib/Tooltip';
import { IPersonaProps, Persona, PersonaPresence } from 'office-ui-fabric-react/lib/Persona';
import {
  CompactPeoplePicker,
  IBasePickerSuggestionsProps,
  IBasePicker,
  ListPeoplePicker,
  NormalPeoplePicker,
  ValidationState
} from 'office-ui-fabric-react/lib/Pickers';
import { BaseComponent, assign } from 'office-ui-fabric-react/lib/Utilities';
import { IPersonaWithMenu } from 'office-ui-fabric-react/lib/components/pickers/PeoplePicker/PeoplePickerItems/PeoplePickerItem.types';
// import { people, mru } from './PeoplePickerExampleData';
import * as jquery from 'jquery';
// import { ITaskManagerProps } from './../ITaskManagerProps';

export interface ITeamMemberState {
 hideDialog: boolean;
 items:ISpTaskItem[];
 userDate : IUserData[];

  currentPicker?: number | string;
  delayResults?: boolean;
  peopleList: IPersonaProps[];
  currentSelectedItems?: IPersonaProps[];
   mostRecentlyUsed: IPersonaProps[];
}

export interface ISpTaskItem{
    Id?: number;
    ProjectID?: string;
    StartDate?: string;
    EndDate?: string;
    Status?: string;
    TeamMember: {
      ID: number,
      Title: string
    }
      Project: {
      ID: number,
      Title: string
    }
  
  }

  export interface IUserData {
    key : number;
    text : string;
    email : string;
    imageUrl : string;
  }

  const suggestionProps: IBasePickerSuggestionsProps = {
  suggestionsHeaderText: 'Suggested People',
  mostRecentlyUsedHeaderText: 'Suggested Contacts',
  noResultsFoundText: 'No results found',
  loadingText: 'Loading',
  showRemoveButtons: true,
  suggestionsAvailableAlertText: 'People Picker Suggestions available',
  suggestionsContainerAriaLabel: 'Suggested contacts'
};

const limitedSearchAdditionalProps: IBasePickerSuggestionsProps = {
  searchForMoreText: 'Load all Results',
  resultsMaximumNumber: 10,
  searchingText: 'Searching...'
  
};

const limitedSearchSuggestionProps: IBasePickerSuggestionsProps = assign(limitedSearchAdditionalProps, suggestionProps);

export default class TeamMember extends React.Component<{}, ITeamMemberState> {

private _picker: IBasePicker<IPersonaProps>;
  constructor(props: {}) {
    super(props);
    const people: (IPersonaProps & { key: string | number })[] = this.state.userDate ;
    const mru: IPersonaProps[] = people.slice(0, 5);
    const peopleList: IPersonaWithMenu[] = [];
    people.forEach((persona: IPersonaProps) => {
      const target: IPersonaWithMenu = {};

      assign(target, persona);
      peopleList.push(target);
    });

    this.state = {
      hideDialog: true,
      items: [],
      userDate : [],

      currentPicker: 1,
      delayResults: false,
      peopleList: peopleList,
      currentSelectedItems: [],
      mostRecentlyUsed: mru
    };
  }


   public componentDidMount() {
       this._getListItems();
       this._getAllSiteUsers();
    //    const people: (IPersonaProps & { key: string | number })[] = this.state.userDate ;
    //    const mru: IPersonaProps[] = people.slice(0, 5);
  }

      public render(): React.ReactElement<ITeamMemberState> {
          
           limitedSearchSuggestionProps.resultsFooter = this._renderFooterText;
        return (
            <div>  
                <div  onClick={this._showDialog} style={{float: "right" }}>  
                 <TooltipHost directionalHint={DirectionalHint.bottomCenter} content="People on this board" id="ppl" calloutProps={{ gapSpace: 0 }}>
                  <Icon id="ppl" iconName="people" className="ms-IconExample" style={{width: "30"}} />
                   </TooltipHost>
                </div>

                <Dialog
                
                hidden={this.state.hideDialog}
                onDismiss={this._closeDialog}
                dialogContentProps={{
                    type: DialogType.close,
                    title: 'Add Team Subscribers',
                }}
                modalProps={{
                    isBlocking: false,
                    containerClassName: 'ms-dialogMainOverride'
                }}
                >
               
                <div>
                    
                     <CompactPeoplePicker
                        onResolveSuggestions={this._onFilterChangedWithLimit}
                        onEmptyInputFocus={this._returnMostRecentlyUsedWithLimit}
                        getTextFromItem={this._getTextFromItem}
                        className={'ms-PeoplePicker'}
                        onGetMoreResults={this._onFilterChanged}
                        pickerSuggestionsProps={limitedSearchSuggestionProps}
                        onRemoveSuggestion={this._onRemoveSuggestion}
                        inputProps={{
                        onBlur: (ev: React.FocusEvent<HTMLInputElement>) => console.log('onBlur called'),
                        onFocus: (ev: React.FocusEvent<HTMLInputElement>) => console.log('onFocus called'),
                        'aria-label': 'People Picker'
                        }}
                    
                        resolveDelay={300}
                    />
                </div>

               <div >

                        {this.state.items.map(function(item,key){  
                            if(item.EndDate == null)
                            {
                                return (
                             
                                        <table className="table-users table" style={{ Border : "0", marginBottom: "0px"}} >
                                            <tbody>
                                                 <tr>
                                                      <td style={{width: "90%"}} >{item.TeamMember.Title} </td>
                                                      <td style={{width: "10%"}} > <Icon iconName="clear" className="ms-IconExample" onClick={(e) => this._deleteListItem(e,item.Id)} /></td>
                                                 </tr>
                                            </tbody>
                                        </table>
                                      );
                            }
                         
           
                        })}
                 </div>
                 

                 <DialogFooter>
                    <PrimaryButton onClick={this._closeDialog} text="Save" />
                    
                </DialogFooter>
                </Dialog>
            
            </div>
        );
      } // end of render()

// Get all site users for peoplePicker

  private _getAllSiteUsers = (): void => {
    var reactHandler = this;  
    sp.web.siteUsers.get().then(function(data) {  

        console.log("data", data);
        var userID = "";
        var userName = "";
        var userEmail = "";
        for (var i = 0; i < data.length; i++) {  
            userID = data[i].Id;
            userName = data[i].Title;  
            userEmail = data[i].LoginName.split('|')[2];
            reactHandler.GetUserPictureUrl(userID,userName,userEmail);
    }  
}); 
  };

  

  
  GetUserPictureUrl(userID,userName,userEmail){  
            var i = 0;
            var reactHandler = this;    
            jquery.ajax({    
            
            url:` https://esplrms.sharepoint.com/sites/rms/_api/SP.UserProfiles.PeopleManager/GetUserProfilePropertyFor(accountName=@v,propertyName='PictureURL')?@v=%27i:0%23.f|membership|`+ userEmail +`%27` , 
          

                type: "GET",    
                headers:{'Accept': 'application/json; odata=verbose;'},    
                success: function(PicData) {
                var img;
                if(PicData.d.GetUserProfilePropertyFor != "" )
                {    
                     img = PicData.d.GetUserProfilePropertyFor;
                }
                else
                    img = "https://esplrms.sharepoint.com/sites/rms/SiteAssets/default.jpg";

                reactHandler.setState(prevState => ({
                    userDate : [...prevState.userDate, {  key : userID , text : userName, email : userEmail , imageUrl : img }]
                })) 

                },    
                error : function(PicData) {
                    console.log('Error Occurred !');     
                }    
            });    
 }


//
  private _showDialog = (): void => {
    this.setState({ hideDialog: false });
  };

  private _closeDialog = (): void => {
    this.setState({ hideDialog: true });
  };

  
   private _getListItems(): void {
    let list = sp.web.lists.getByTitle("Project Team Member");
       list.items
      .select("ID","ProjectID", "StartDate", "EndDate", "Status","TeamMember/Title", "TeamMember/ID", "Project/Title", "Project/ID").expand("TeamMember","Project").filter("Project/ID eq 1")
      .get()
      .then((response) => {
        // console.log(response);
        this.setState({
          items: response
        });
      });
  }

  private _deleteListItem(e,itemID) : void {
     let list = sp.web.lists.getByTitle("Project Team Member");
     list.items.getById(itemID).delete().then( response => {
         alert("item deleted successfully!");
     });
  }

//   private _deleteListItem() : void {
//     //  let list = sp.web.lists.getByTitle("Project Team Member");
//     //  list.items.getById(itemID).delete().then( response => {
//          alert("item deleted successfully!");
//     //  });
//   }

  private _addListItem() : void {
  let list = sp.web.lists.getByTitle("Project Team Member").items.add({
    Title: "No Title",
    StartDate : Date.now,
    Status : "Active", 
    // TeamMemberId : 
    // ProjectId :
}).then(console.log).catch(console.log);
  }

// PeoplePicker

    private _renderFooterText = (): JSX.Element => {
    return <div>No additional results</div>;
  };

    private _onFilterChangedWithLimit = (
    filterText: string,
    currentPersonas: IPersonaProps[]
  ): IPersonaProps[] | Promise<IPersonaProps[]> => {
     return this._onFilterChanged(filterText, currentPersonas, 3);
  };

    private _onFilterChanged = (
    filterText: string,
    currentPersonas: IPersonaProps[],
    limitResults?: number
  ): IPersonaProps[] | Promise<IPersonaProps[]> => {
    if (filterText) {
      let filteredPersonas: IPersonaProps[] = this._filterPersonasByText(filterText);

      filteredPersonas = this._removeDuplicates(filteredPersonas, currentPersonas);
      filteredPersonas = limitResults ? filteredPersonas.splice(0, limitResults) : filteredPersonas;
      return this._filterPromise(filteredPersonas);
    } else {
      return [];
    }
  };

    private _filterPersonasByText(filterText: string): IPersonaProps[] {
     return this.state.peopleList.filter(item => this._doesTextStartWith(item.text as string, filterText));
  }
    private _doesTextStartWith(text: string, filterText: string): boolean {
    return text.toLowerCase().indexOf(filterText.toLowerCase()) === 0;
  }

    private _removeDuplicates(personas: IPersonaProps[], possibleDupes: IPersonaProps[]) {
    return personas.filter(persona => !this._listContainsPersona(persona, possibleDupes));
  }

    private _listContainsPersona(persona: IPersonaProps, personas: IPersonaProps[]) {
    if (!personas || !personas.length || personas.length === 0) {
      return false;
    }
    return personas.filter(item => item.text === persona.text).length > 0;
  }

    private _filterPromise(personasToReturn: IPersonaProps[]): IPersonaProps[] | Promise<IPersonaProps[]> {
    if (this.state.delayResults) {
      return this._convertResultsToPromise(personasToReturn);
    } else {
      return personasToReturn;
    }
  }

    private _convertResultsToPromise(results: IPersonaProps[]): Promise<IPersonaProps[]> {
    return new Promise<IPersonaProps[]>((resolve, reject) => setTimeout(() => resolve(results), 2000));
  }

    private _returnMostRecentlyUsedWithLimit = (
    currentPersonas: IPersonaProps[]
  ): IPersonaProps[] | Promise<IPersonaProps[]> => {
    let { mostRecentlyUsed } = this.state;
    mostRecentlyUsed = this._removeDuplicates(mostRecentlyUsed, currentPersonas);
    mostRecentlyUsed = mostRecentlyUsed.splice(0, 3);
    return this._filterPromise(mostRecentlyUsed);
  };

    private _getTextFromItem(persona: IPersonaProps): string {
    return persona.text as string;
  }

    private _onRemoveSuggestion = (item: IPersonaProps): void => {
    const { peopleList, mostRecentlyUsed: mruState } = this.state;
    const indexPeopleList: number = peopleList.indexOf(item);
    const indexMostRecentlyUsed: number = mruState.indexOf(item);

    if (indexPeopleList >= 0) {
      const newPeople: IPersonaProps[] = peopleList
        .slice(0, indexPeopleList)
        .concat(peopleList.slice(indexPeopleList + 1));
      this.setState({ peopleList: newPeople });
    }

    if (indexMostRecentlyUsed >= 0) {
      const newSuggestedPeople: IPersonaProps[] = mruState
        .slice(0, indexMostRecentlyUsed)
        .concat(mruState.slice(indexMostRecentlyUsed + 1));
      this.setState({ mostRecentlyUsed: newSuggestedPeople });
    }
  };


  
}